OS: Windows 10 running on Windows command line
Borland Version: 5.5

flags: none

run as user

