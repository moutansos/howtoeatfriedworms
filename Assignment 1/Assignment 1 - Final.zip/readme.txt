Assignment 2: Team - Self replicating program
Attempting Extra Credit

Ben Brougher
Travis Currier
Daylyn Hoxie

Within folder Iteration-0 is the output of our self replicating program. It only replicates 10 times.
The diff of the original main and the sub iteration is in the file diff.png file.

There are no significant shortcomings in this program. The only difference between the files is a small bit of whitespace at the end of the program string.